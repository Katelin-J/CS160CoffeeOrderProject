public class Espresso extends CoffeeDecorator{
    public Espresso(Coffee coffee) {
        super(coffee);
    }

    @Override
    public void addTopping(Coffee coffee) {
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " and espresso";
    }

    @Override
    double cost() {
        double cost = 0.35;
        return cost;
    }
}
