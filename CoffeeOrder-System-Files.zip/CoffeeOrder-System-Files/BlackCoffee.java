public class BlackCoffee extends CoffeeDecorator {
    public BlackCoffee(Coffee coffee) {
        super(coffee);
    }

    public BlackCoffee() {
        super();
    }

    @Override
    public void addTopping(Coffee coffee) {
        instructions();
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee();
    }

    public void instructions() {
        System.out.println("Pour coffee from pot into cup");
    }

    @Override
    double cost() {
        double cost = 0.85;
        return cost;
    }
}
