public class HotWater extends CoffeeDecorator{
    public HotWater(Coffee coffee) {
        super(coffee);
    }

    @Override
    public void addTopping(Coffee coffee) {
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " and hot water";
    }

    @Override
    double cost() {
        double cost = 0.0;
        return cost;
    }
}
