public interface Coffee {

    void addTopping(Coffee coffee);
    String printCoffee();
}
