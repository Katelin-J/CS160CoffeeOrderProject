public class WhippedCream extends CoffeeDecorator {

    public WhippedCream(Coffee coffee) {
        super(coffee);
    }
    @Override
    public void addTopping(Coffee coffee){
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " and whipped cream";
    }

    @Override
    double cost() {
        double cost = 0.10;
        return cost;
    }
}
